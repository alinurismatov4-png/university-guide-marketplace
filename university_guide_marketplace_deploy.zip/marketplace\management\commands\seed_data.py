from datetime import date
from django.core.management.base import BaseCommand
from marketplace.models import User, University, GuideProfile, Scholarship, Message


class Command(BaseCommand):
    help = 'Очищает базу от вымышленных демо-профилей и загружает реальные университеты и настоящие стипендии'

    def handle(self, *args, **options):
        self.stdout.write('Удаляем тестовые/вымышленные профили людей и демо-сообщения...')

        fake_usernames = [
            'daler_applicant',
            'amina_applicant',
            'farzona_malaysia',
            'komron_china',
            'malika_italy',
            'behruz_turkey',
            'siyovush_hungary',
            'rustam_pending',
        ]
        deleted_count, _ = User.objects.filter(username__in=fake_usernames).delete()
        self.stdout.write(f'Удалено тестовых записей: {deleted_count}')

        # 1. Аккаунт администратора платформы
        admin_user, _ = User.objects.update_or_create(
            username='admin',
            defaults={
                'full_name': 'Администратор Платформы',
                'email': 'admin@uniguide.tj',
                'role': User.ROLE_ADMIN,
                'country_of_origin': 'Таджикистан, Душанбе',
                'is_staff': True,
                'is_superuser': True,
            },
        )
        admin_user.set_password('admin123')
        admin_user.save()

        # 2. Реальные университеты (Малайзия, Китай, Италия, Турция, Венгрия)
        universities_data = [
            {
                'name': 'Asia Pacific University of Technology & Innovation (APU)',
                'country': 'Малайзия',
                'city': 'Куала-Лумпур',
                'flag_emoji': '🇲🇾',
                'website': 'https://www.apu.edu.my',
                'programs': 'Computer Science, Software Engineering, AI & Data Science, Cyber Security, International Business, Finance & FinTech',
                'language_of_instruction': 'Английский (100%)',
                'tuition_fee': '$4,800 – $6,200 / год (со скидкой до 30%)',
                'living_cost': '$300 – $450 / месяц (общежитие + питание)',
                'accepts_after_grade_11': True,
                'after_grade_11_info': (
                    'После 11 класса школы Таджикистана вы поступаете на программу Foundation (1 год) '
                    'или Diploma, после чего автоматически переходите на бакалавриат (3 года) с двойным '
                    'дипломом APU + De Montfort University (Великобритания).'
                ),
                'required_documents': (
                    '1. Аттестат за 11 класс с приложением (перевод на английский язык)\n'
                    '2. Скан загранпаспорта (все страницы)\n'
                    '3. Фото 3.5x4.5 на белом фоне\n'
                    '4. Сертификат IELTS 5.5+ (или внутренний онлайн-тест по английскому в вузе)\n'
                    '5. Медицинская форма Health Declaration'
                ),
                'visa_info': (
                    'Вуз сам подаёт ваши документы в систему EMGS (Education Malaysia Global Services) для получения '
                    'VAL (Visa Approval Letter). Оформление занимает 4–6 недель. По прилёте в Куала-Лумпур ставится Student Pass.'
                ),
                'student_life': (
                    'В кампусе учатся студенты из 130+ стран, в том числе более 150 ребят из Таджикистана и СНГ. '
                    'Круглый год лето (+28°C), халяльная еда на каждом шагу, современные IT-лаборатории и бассейны при общежитиях.'
                ),
                'ranking_badge': 'Топ-1 технологический вуз Малайзии • Двойной диплом с Британией',
            },
            {
                'name': 'Zhejiang University (Чжэцзянский университет)',
                'country': 'Китай',
                'city': 'Ханчжоу',
                'flag_emoji': '🇨🇳',
                'website': 'https://www.zju.edu.cn/english/',
                'programs': 'Computer Science, International Trade, Civil Engineering, Biomedical Sciences, Chinese Language & Literature, Robotics',
                'language_of_instruction': 'Английский или Китайский',
                'tuition_fee': '$0 по гранту CSC (или $3,200 / год без гранта)',
                'living_cost': '$220 – $350 / месяц (кампус в Ханчжоу)',
                'accepts_after_grade_11': True,
                'after_grade_11_info': (
                    'Принимают сразу после 11 класса! Если знаете английский (IELTS 6.0+), можно сразу на англоязычный '
                    'бакалавриат. Если хотите учиться на китайском по гранту — сначала 1 год языкового курса (Foundation Chinese), затем 4 года бакалавриата.'
                ),
                'required_documents': (
                    '1. Аттестат за 11 класс (или справка из школы, если учитесь в 11 классе) с нотариальным переводом\n'
                    '2. Загранпаспорт\n'
                    '3. Медкомиссия для иностранцев (Foreigner Physical Examination Form)\n'
                    '4. Справка о несудимости\n'
                    '5. Study Plan (мотивационное письмо на 800 слов) и 2 рекомендации от учителей\n'
                    '6. Сертификат IELTS / TOEFL или HSK 4–5'
                ),
                'visa_info': (
                    'После зачисления университет присылает Admission Notice и форму JW201/JW202. С ними вы подаёте на '
                    'студенческую визу X1 в посольстве КНР в Душанбе за 1 неделю.'
                ),
                'student_life': (
                    'Ханчжоу — родина Alibaba и один из самых безопасных и технологичных городов мира. '
                    'Огромный кампус Zijingang как целый город: столовые по $1.5–$2 за обед, скоростные поезда до Шанхая за 45 минут.'
                ),
                'ranking_badge': 'Топ-50 мира QS • Лига C9 (Китайская Лига Плюща)',
            },
            {
                'name': 'University of Bologna (Болонский университет)',
                'country': 'Италия',
                'city': 'Болонья',
                'flag_emoji': '🇮🇹',
                'website': 'https://www.unibo.it/en',
                'programs': 'Economics & Finance, Business & Economics (CLABE), International Relations, Artificial Intelligence, Engineering, Medicine',
                'language_of_instruction': 'Английский или Итальянский',
                'tuition_fee': '€0 – €157 / год (со стипендией ER.GO / DSU по доходу семьи)',
                'living_cost': '€450 – €650 / месяц (покрывается стипендией €6,500/год)',
                'accepts_after_grade_11': False,
                'after_grade_11_info': (
                    'Для Италии требуется 12 лет обучения! У выпускников из Таджикистана есть 2 пути:\n'
                    'Вариант А: Отучиться 1 курс в любом университете Таджикистана и сразу подать на 1 курс бакалавриата в Италию.\n'
                    'Вариант Б: Поступить сразу после 11 класса на программу Foundation Year (1 год) при итальянском вузе.'
                ),
                'required_documents': (
                    '1. Аттестат за 11 класс + справка об окончании 1 курса вуза (или диплом колледжа) с апостилем\n'
                    '2. Сертификат TOLC-E / TOLC-I или SAT (сдаётся онлайн)\n'
                    '3. IELTS 5.5–6.0\n'
                    '4. Документы о доходах семьи и составе семьи из Таджикистана (для получения полной стипендии DSU/ER.GO)\n'
                    '5. Регистрация на портале Universitaly'
                ),
                'visa_info': (
                    'Подача через портал Universitaly (предварительная запись до июня), затем получение визы типа D. '
                    'Важно заранее собрать финансовые гарантии и бронь жилья.'
                ),
                'student_life': (
                    'Старейший университет Европы (основан в 1088 году)! Студенческий город, бесплатные обеды в столовых Mensa '
                    'для стипендиатов, путешествия по всему Шенгену и право подрабатывать до 20 часов в неделю.'
                ),
                'ranking_badge': 'Стипендия DSU/ER.GO по доходу семьи до €7,000/год',
            },
            {
                'name': 'Universiti Malaya (UM)',
                'country': 'Малайзия',
                'city': 'Куала-Лумпур',
                'flag_emoji': '🇲🇾',
                'website': 'https://www.um.edu.my',
                'programs': 'Data Science, Mechanical Engineering, Economics, Accounting, Media Studies, Biotechnology',
                'language_of_instruction': 'Английский',
                'tuition_fee': '$3,500 – $5,000 / год',
                'living_cost': '$280 – $400 / месяц',
                'accepts_after_grade_11': True,
                'after_grade_11_info': (
                    'Поступление после 11 класса через программу Foundation in Science / Foundation in Arts '
                    'или после 1 курса отечественного вуза напрямую на бакалавриат.'
                ),
                'required_documents': (
                    '1. Аттестат с отличными оценками (средний балл 85%+)\n'
                    '2. Сертификат IELTS 6.0\n'
                    '3. Загранпаспорт и фото\n'
                    '4. Мотивационное письмо'
                ),
                'visa_info': (
                    'Электронное разрешение EMGS VAL оформляется через визовый отдел университета онлайн без поездок в посольство.'
                ),
                'student_life': (
                    'Главный государственный вуз Малайзии (Топ-60 мира в рейтинге QS). Огромный зелёный кампус в центре '
                    'Куала-Лумпура, недорогие государственные общежития (Kolej Kediaman) и сильное международное сообщество.'
                ),
                'ranking_badge': 'Топ-60 мира QS • Главный государственный вуз Малайзии',
            },
            {
                'name': 'Middle East Technical University (METU / ODTÜ)',
                'country': 'Турция',
                'city': 'Анкара',
                'flag_emoji': '🇹🇷',
                'website': 'https://www.metu.edu.tr',
                'programs': 'Computer Engineering, Architecture, Aerospace Engineering, International Relations, Business Administration',
                'language_of_instruction': 'Английский (100%)',
                'tuition_fee': '$1,000 – $1,500 / год (или $0 по гранту Türkiye Bursları)',
                'living_cost': '$250 – $380 / месяц',
                'accepts_after_grade_11': True,
                'after_grade_11_info': (
                    'Принимает выпускников 11 класса Таджикистана напрямую! Можно поступить как по государственному '
                    'гранту Türkiye Bursları, так и самостоятельно по результатам SAT (от 1250+) или аттестата.'
                ),
                'required_documents': (
                    '1. Аттестат за 11 класс (или табель за 10–11 класс при подаче зимой)\n'
                    '2. Сертификат SAT или TR-YÖS\n'
                    '3. Сертификат английского или сдача внутреннего экзамена METU EPE\n'
                    '4. Загранпаспорт'
                ),
                'visa_info': (
                    'Студенческая виза оформляется в посольстве Турции в Душанбе по письму о зачислении (Kabul Mektubu), '
                    'в Анкаре оформляется ВНЖ (İkamet).'
                ),
                'student_life': (
                    'Кампус с собственным озером Эймир и лесом, полностью англоязычное обучение и диплом, признаваемый в США и Европе. '
                    'Очень близкая культура и прямые рейсы из Душанбе.'
                ),
                'ranking_badge': 'Лучший англоязычный технический вуз Турции',
            },
            {
                'name': 'University of Debrecen (Дебреценский университет)',
                'country': 'Венгрия',
                'city': 'Дебрецен',
                'flag_emoji': '🇭🇺',
                'website': 'https://edu.unideb.hu',
                'programs': 'Computer Science Engineering, Business Administration, General Medicine, Public Health, Mechatronics',
                'language_of_instruction': 'Английский',
                'tuition_fee': '€0 по гранту Stipendium Hungaricum (или €6,500 / год)',
                'living_cost': '€300 – €450 / месяц',
                'accepts_after_grade_11': True,
                'after_grade_11_info': (
                    'Принимает сразу после 11 класса! Ежегодно выделяются квоты правительственной стипендии '
                    'Stipendium Hungaricum для граждан Таджикистана (подача с ноября по 15 января).'
                ),
                'required_documents': (
                    '1. Аттестат за 11 класс (или справка из школы)\n'
                    '2. Мотивационное письмо на английском\n'
                    '3. Сертификат IELTS 5.5+ (или внутреннее собеседование)\n'
                    '4. Медицинская справка\n'
                    '5. Загранпаспорт'
                ),
                'visa_info': (
                    'Для стипендиатов Stipendium Hungaricum виза категории D и студенческий ВНЖ Евросоюза оформляются бесплатно.'
                ),
                'student_life': (
                    'Спокойный и безопасный европейский студенческий город, европейский диплом и возможность путешествовать по всей Шенгенской зоне.'
                ),
                'ranking_badge': 'Полный грант Stipendium Hungaricum для Таджикистана',
            },
        ]

        uni_objects = {}
        for item in universities_data:
            uni, _ = University.objects.update_or_create(
                name=item['name'],
                defaults=item,
            )
            uni_objects[item['name']] = uni

        # 3. Настоящие стипендиальные программы (Scholarship)
        scholarships_data = [
            {
                'title': 'Chinese Government Scholarship (CSC — Полный грант КНР)',
                'university': uni_objects['Zhejiang University (Чжэцзянский университет)'],
                'country': 'Китай',
                'coverage_type': Scholarship.COVERAGE_FULL,
                'amount_summary': '100% обучение + бесплатное общежитие + страховка + стипендия 2500 юаней/мес (~$350)',
                'conditions': (
                    'Доступна выпускникам 11 класса из Таджикистана (возраст до 25 лет для бакалавриата). '
                    'Отличная успеваемость в школе, медицинская справка, сертификат HSK 3–4 (или IELTS 6.0 для англоязычных программ), '
                    'качественный Study Plan.'
                ),
                'deadline': date(2027, 2, 20),
                'official_link': 'https://www.campuschina.org',
            },
            {
                'title': 'Региональная стипендия Италии DSU / ER.GO (по доходу семьи)',
                'university': uni_objects['University of Bologna (Болонский университет)'],
                'country': 'Италия',
                'coverage_type': Scholarship.COVERAGE_FULL,
                'amount_summary': '100% освобождение от оплаты вуза + €6,500–€7,000 в год на руки + бесплатное питание',
                'conditions': (
                    'Не требует золотой медали! Назначается студентам, чей семейный доход (показатель ISEE Parificato) '
                    'ниже €24,000 в год (подходит 95% абитуриентов из Таджикистана и СНГ). Нужен пакет справок о составе и доходах семьи с апостилем.'
                ),
                'deadline': date(2027, 8, 30),
                'official_link': 'https://www.er-go.it',
            },
            {
                'title': 'Stipendium Hungaricum (Правительственный грант Венгрии для Таджикистана)',
                'university': uni_objects['University of Debrecen (Дебреценский университет)'],
                'country': 'Венгрия',
                'coverage_type': Scholarship.COVERAGE_FULL,
                'amount_summary': '100% обучение в ЕС + место в общежитии + медстраховка + ежемесячная стипендия',
                'conditions': (
                    'Подача открыта для школьников 11 класса и студентов из Таджикистана. '
                    'Требуется аттестат (или справка из 11 класса), знание английского B2 (IELTS 5.5+) и сдача онлайн-собеседования вуза.'
                ),
                'deadline': date(2027, 1, 15),
                'official_link': 'https://stipendiumhungaricum.hu',
            },
            {
                'title': 'Türkiye Bursları (Государственная стипендия Турции)',
                'university': uni_objects['Middle East Technical University (METU / ODTÜ)'],
                'country': 'Турция',
                'coverage_type': Scholarship.COVERAGE_FULL,
                'amount_summary': '100% обучение + общежитие + авиабилеты туда и обратно + курс турецкого языка + стипендия',
                'conditions': (
                    'Средний балл аттестата не ниже 70% (на медицину — 90%), возраст до 21 года для бакалавриата. '
                    'Подача полностью бесплатная онлайн в январе–феврале.'
                ),
                'deadline': date(2027, 2, 20),
                'official_link': 'https://www.turkiyeburslari.gov.tr',
            },
            {
                'title': 'APU Merit Scholarship для студентов из СНГ и Центральной Азии',
                'university': uni_objects['Asia Pacific University of Technology & Innovation (APU)'],
                'country': 'Малайзия',
                'coverage_type': Scholarship.COVERAGE_PARTIAL,
                'amount_summary': 'Скидка от 20% до 35% на весь период обучения на бакалавриате',
                'conditions': (
                    'Автоматически предоставляется выпускникам 11 класса со средним баллом аттестата 4.5+ из 5.0 '
                    'и при поддержании GPA выше 3.2 во время учёбы.'
                ),
                'deadline': date(2027, 7, 15),
                'official_link': 'https://www.apu.edu.my',
            },
        ]

        for s in scholarships_data:
            Scholarship.objects.update_or_create(
                title=s['title'],
                defaults=s,
            )

        self.stdout.write(self.style.SUCCESS('База очищена от вымышленных людей. Реальные университеты и стипендии сохранены!'))
