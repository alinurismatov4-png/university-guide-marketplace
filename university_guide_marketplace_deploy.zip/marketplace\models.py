from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Три типа пользователей платформы:
    1. Applicant — абитуриент
    2. Guide — гид или наставник (студент / выпускник)
    3. Admin — администратор
    """
    ROLE_APPLICANT = 'applicant'
    ROLE_GUIDE = 'guide'
    ROLE_ADMIN = 'admin'

    ROLE_CHOICES = [
        (ROLE_APPLICANT, 'Абитуриент (Applicant)'),
        (ROLE_GUIDE, 'Гид / Наставник (Guide)'),
        (ROLE_ADMIN, 'Администратор (Admin)'),
    ]

    full_name = models.CharField('Имя и фамилия', max_length=150)
    email = models.EmailField('Email', unique=True)
    role = models.CharField(
        'Роль пользователя',
        max_length=20,
        choices=ROLE_CHOICES,
        default=ROLE_APPLICANT,
    )
    country_of_origin = models.CharField(
        'Откуда вы (страна / город)',
        max_length=100,
        default='Таджикистан, Душанбе',
        blank=True,
    )

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

    def __str__(self):
        display = self.full_name or self.username
        return f"{display} ({self.get_role_display()})"

    @property
    def is_applicant(self):
        return self.role == self.ROLE_APPLICANT

    @property
    def is_guide(self):
        return self.role == self.ROLE_GUIDE

    @property
    def is_platform_admin(self):
        return self.role == self.ROLE_ADMIN or self.is_superuser or self.is_staff

    @property
    def initials(self):
        name = (self.full_name or self.username).strip()
        parts = name.split()
        if len(parts) >= 2:
            return (parts[0][0] + parts[1][0]).upper()
        return name[:2].upper()


class University(models.Model):
    """
    Профиль университета:
    Название, страна, город, сайт, программы обучения, а также ответы
    на главные вопросы абитуриентов (поступление после 11 класса,
    документы, стоимость обучения и проживания, виза, студенческая жизнь).
    """
    name = models.CharField('Название университета', max_length=200)
    country = models.CharField('Страна', max_length=100)
    city = models.CharField('Город', max_length=100)
    flag_emoji = models.CharField('Флаг страны (эмодзи)', max_length=16, default='🎓')
    website = models.URLField('Официальный сайт', max_length=300)
    programs = models.TextField(
        'Программы обучения',
        help_text='Перечислите популярные факультеты и направления (через запятую или с новой строки)',
    )
    language_of_instruction = models.CharField(
        'Язык обучения',
        max_length=120,
        default='Английский',
    )
    tuition_fee = models.CharField(
        'Стоимость обучения в год',
        max_length=150,
        default='$3,000 – $5,500 / год',
    )
    living_cost = models.CharField(
        'Проживание и питание в месяц',
        max_length=150,
        default='$250 – $400 / месяц',
    )
    accepts_after_grade_11 = models.BooleanField(
        'Можно поступить сразу после 11 класса',
        default=True,
    )
    after_grade_11_info = models.TextField(
        'Как поступить после 11 класса?',
        help_text='Описание траектории поступления для выпускников школ СНГ / Таджикистана',
    )
    required_documents = models.TextField(
        'Какие документы нужны?',
    )
    visa_info = models.TextField(
        'Как получить студенческую визу?',
    )
    student_life = models.TextField(
        'Реальная студенческая жизнь и кампус',
    )
    ranking_badge = models.CharField(
        'Рейтинг / Особенность вуза',
        max_length=120,
        blank=True,
        default='Популярный выбор студентов из СНГ',
    )
    is_verified = models.BooleanField(
        'Подтверждён администратором',
        default=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Университет'
        verbose_name_plural = 'Университеты'
        ordering = ['country', 'name']

    def __str__(self):
        return f"{self.name} ({self.country}, {self.city})"

    def programs_list(self):
        return [p.strip() for p in self.programs.replace('\n', ',').split(',') if p.strip()]


class GuideProfile(models.Model):
    """
    Профиль гида / наставника:
    Пользователь, университет, специальность, статус проверки, описание опыта.
    """
    STATUS_PENDING = 'pending'
    STATUS_VERIFIED = 'verified'
    STATUS_REJECTED = 'rejected'

    VERIFICATION_CHOICES = [
        (STATUS_PENDING, 'На проверке у администратора'),
        (STATUS_VERIFIED, 'Подтверждён (Verified Student/Alumni)'),
        (STATUS_REJECTED, 'Отклонён'),
    ]

    ACADEMIC_BACHELOR = 'bachelor'
    ACADEMIC_MASTER = 'master'
    ACADEMIC_ALUMNI = 'alumni'

    ACADEMIC_CHOICES = [
        (ACADEMIC_BACHELOR, 'Студент бакалавриата'),
        (ACADEMIC_MASTER, 'Студент магистратуры'),
        (ACADEMIC_ALUMNI, 'Выпускник (Alumni)'),
    ]

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='guide_profile',
        verbose_name='Пользователь',
    )
    university = models.ForeignKey(
        University,
        on_delete=models.CASCADE,
        related_name='guides',
        verbose_name='Университет',
    )
    major = models.CharField('Специальность / Факультет', max_length=150)
    academic_status = models.CharField(
        'Статус обучения',
        max_length=25,
        choices=ACADEMIC_CHOICES,
        default=ACADEMIC_BACHELOR,
    )
    study_year = models.CharField(
        'Курс / Год выпуска',
        max_length=80,
        default='2 курс бакалавриата',
    )
    verification_status = models.CharField(
        'Статус проверки',
        max_length=20,
        choices=VERIFICATION_CHOICES,
        default=STATUS_PENDING,
    )
    verification_document_info = models.CharField(
        'Подтверждение статуса (Student ID / корпоративная почта вуза)',
        max_length=200,
        blank=True,
        help_text='Например: Student ID #MY2024-881 или почта @student.apu.edu.my',
    )
    avatar_photo = models.FileField(
        'Фотография профиля (JPG/PNG)',
        upload_to='guides/photos/',
        blank=True,
        null=True,
    )
    student_id_file = models.FileField(
        'Фото/скан студенческого билета или диплома (видит только администратор)',
        upload_to='guides/documents/',
        blank=True,
        null=True,
    )
    telegram_username = models.CharField(
        'Telegram (никнейм или ссылка)',
        max_length=120,
        blank=True,
        help_text='Например: @my_telegram или https://t.me/my_telegram',
    )
    whatsapp_phone = models.CharField(
        'WhatsApp (номер телефона с кодом страны)',
        max_length=50,
        blank=True,
        help_text='Например: +992900123456 или +60123456789',
    )
    instagram_handle = models.CharField(
        'Instagram (никнейм или ссылка)',
        max_length=120,
        blank=True,
        help_text='Например: @my_insta',
    )
    linkedin_url = models.URLField(
        'Профиль LinkedIn',
        max_length=250,
        blank=True,
    )
    has_scholarship = models.BooleanField(
        'Учится со стипендией / грантом',
        default=False,
    )
    scholarship_details = models.CharField(
        'Какая стипендия у гида',
        max_length=160,
        blank=True,
    )
    languages = models.CharField(
        'Языки общения',
        max_length=150,
        default='Таджикский, Русский, Английский',
    )
    experience_description = models.TextField(
        'Описание опыта поступления и учёбы',
    )
    can_help_with = models.TextField(
        'С какими вопросами может помочь',
        default='Выбор программы после 11 класса, подача документов без агентств, получение визы, поиск общежития, подготовка к собеседованию на стипендию.',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Профиль гида'
        verbose_name_plural = 'Профили гидов'
        ordering = ['-verification_status', '-created_at']

    def __str__(self):
        return f"{self.user.full_name or self.user.username} — {self.university.name}"

    @property
    def is_verified(self):
        return self.verification_status == self.STATUS_VERIFIED

    @property
    def telegram_url(self):
        val = (self.telegram_username or '').strip()
        if not val:
            return ''
        if val.startswith('http://') or val.startswith('https://'):
            return val
        return f"https://t.me/{val.lstrip('@')}"

    @property
    def whatsapp_url(self):
        val = (self.whatsapp_phone or '').strip()
        if not val:
            return ''
        digits = ''.join(ch for ch in val if ch.isdigit())
        return f"https://wa.me/{digits}" if digits else ''

    @property
    def instagram_url(self):
        val = (self.instagram_handle or '').strip()
        if not val:
            return ''
        if val.startswith('http://') or val.startswith('https://'):
            return val
        return f"https://instagram.com/{val.lstrip('@')}"

    def help_topics_list(self):
        return [item.strip() for item in self.can_help_with.replace('\n', ',').split(',') if item.strip()]


class Scholarship(models.Model):
    """
    Стипендии и гранты:
    Название стипендии, университет, страна, условия, дедлайн.
    """
    COVERAGE_FULL = 'full'
    COVERAGE_TUITION = 'tuition'
    COVERAGE_PARTIAL = 'partial'

    COVERAGE_CHOICES = [
        (COVERAGE_FULL, 'Полная стипендия (100% обучение + проживание / стипендия)'),
        (COVERAGE_TUITION, '100% покрытие обучения'),
        (COVERAGE_PARTIAL, 'Частичный грант / скидка (30% – 70%)'),
    ]

    title = models.CharField('Название стипендии', max_length=200)
    university = models.ForeignKey(
        University,
        on_delete=models.CASCADE,
        related_name='scholarships',
        verbose_name='Университет',
    )
    country = models.CharField('Страна', max_length=100)
    coverage_type = models.CharField(
        'Тип покрытия',
        max_length=20,
        choices=COVERAGE_CHOICES,
        default=COVERAGE_FULL,
    )
    amount_summary = models.CharField(
        'Что покрывает стипендия',
        max_length=200,
        default='100% обучения + общежитие + ежемесячная выплата',
    )
    conditions = models.TextField('Условия получения и требования')
    deadline = models.DateField('Дедлайн подачи')
    official_link = models.URLField('Ссылка на описание гранта', blank=True)

    class Meta:
        verbose_name = 'Стипендия'
        verbose_name_plural = 'Стипендии'
        ordering = ['deadline']

    def __str__(self):
        return f"{self.title} ({self.country} — {self.university.name})"


class Message(models.Model):
    """
    Contact / Message:
    Абитуриент, гид, сообщение, дата.
    Поддерживает полноценную переписку между абитуриентом и гидом.
    """
    TOPIC_CHOICES = [
        ('admission_11', 'Поступление после 11 класса'),
        ('documents', 'Какие документы нужны'),
        ('scholarship', 'Стипендии и гранты'),
        ('costs', 'Стоимость обучения и проживания'),
        ('visa', 'Получение студенческой визы'),
        ('student_life', 'Реальная студенческая жизнь и общежитие'),
        ('other', 'Другой вопрос'),
    ]

    applicant = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='applicant_messages',
        verbose_name='Абитуриент',
    )
    guide = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='guide_messages',
        verbose_name='Гид',
    )
    sender = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='sent_messages',
        verbose_name='Отправитель',
    )
    topic = models.CharField(
        'Тема вопроса',
        max_length=30,
        choices=TOPIC_CHOICES,
        default='admission_11',
    )
    content = models.TextField('Текст сообщения')
    created_at = models.DateTimeField('Дата отправки', auto_now_add=True)
    is_read = models.BooleanField('Прочитано', default=False)

    class Meta:
        verbose_name = 'Сообщение'
        verbose_name_plural = 'Сообщения'
        ordering = ['created_at']

    def __str__(self):
        return f"От {self.sender.username}: {self.content[:40]}..."
