from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('universities/', views.university_list, name='university_list'),
    path('universities/<int:pk>/', views.university_detail, name='university_detail'),
    path('guides/', views.guide_list, name='guide_list'),
    path('guides/<int:pk>/', views.guide_detail, name='guide_detail'),
    path('scholarships/', views.scholarship_list, name='scholarship_list'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('demo-login/<str:role>/', views.demo_login_view, name='demo_login'),
    path('logout/', views.logout_view, name='logout'),
    path('guide/profile/edit/', views.guide_profile_edit, name='guide_profile_edit'),
    path('inbox/', views.inbox_view, name='inbox'),
    path('conversation/<int:partner_id>/', views.conversation_view, name='conversation'),
    path('moderation/', views.moderation_dashboard, name='moderation_dashboard'),
    path('robots.txt', views.robots_txt, name='robots_txt'),
    path('sitemap.xml', views.sitemap_xml, name='sitemap_xml'),
]
