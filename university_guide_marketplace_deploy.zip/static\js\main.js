document.addEventListener('DOMContentLoaded', () => {
    const faqButtons = document.querySelectorAll('.faq-btn');
    const faqPanels = document.querySelectorAll('.faq-panel');

    faqButtons.forEach((btn) => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-target');
            faqButtons.forEach((b) => b.classList.remove('active'));
            faqPanels.forEach((p) => p.classList.remove('active'));

            btn.classList.add('active');
            const panel = document.getElementById(targetId);
            if (panel) {
                panel.classList.add('active');
            }
        });
    });

    const chatContainer = document.querySelector('.chat-messages');
    if (chatContainer) {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
});
