from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Count
from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse

from .models import User, University, GuideProfile, Scholarship, Message
from .forms import (
    UserRegistrationForm,
    CustomLoginForm,
    GuideProfileForm,
    MessageForm,
    UniversityForm,
)


def home(request):
    query = request.GET.get('q', '').strip()
    country = request.GET.get('country', '').strip()

    universities = University.objects.filter(is_verified=True).annotate(
        guides_count=Count('guides', filter=Q(guides__verification_status=GuideProfile.STATUS_VERIFIED))
    )
    if country:
        universities = universities.filter(country__iexact=country)
    if query:
        universities = universities.filter(
            Q(name__icontains=query)
            | Q(country__icontains=query)
            | Q(city__icontains=query)
            | Q(programs__icontains=query)
        )

    featured_universities = universities[:6]
    verified_guides = (
        GuideProfile.objects.filter(verification_status=GuideProfile.STATUS_VERIFIED)
        .select_related('user', 'university')[:6]
    )
    featured_scholarships = Scholarship.objects.select_related('university')[:4]

    countries = (
        University.objects.filter(is_verified=True)
        .values_list('country', flat=True)
        .distinct()
        .order_by('country')
    )

    stats = {
        'universities_count': University.objects.filter(is_verified=True).count(),
        'guides_count': GuideProfile.objects.filter(verification_status=GuideProfile.STATUS_VERIFIED).count(),
        'scholarships_count': Scholarship.objects.count(),
        'countries_count': countries.count(),
    }

    context = {
        'featured_universities': featured_universities,
        'verified_guides': verified_guides,
        'featured_scholarships': featured_scholarships,
        'countries': countries,
        'stats': stats,
        'search_query': query,
        'selected_country': country,
    }
    return render(request, 'marketplace/home.html', context)


def university_list(request):
    query = request.GET.get('q', '').strip()
    country = request.GET.get('country', '').strip()
    after_11 = request.GET.get('after_11', '').strip()

    universities = University.objects.filter(is_verified=True).annotate(
        guides_count=Count('guides', filter=Q(guides__verification_status=GuideProfile.STATUS_VERIFIED)),
        scholarships_count=Count('scholarships'),
    )

    if query:
        universities = universities.filter(
            Q(name__icontains=query)
            | Q(country__icontains=query)
            | Q(city__icontains=query)
            | Q(programs__icontains=query)
        )
    if country:
        universities = universities.filter(country__iexact=country)
    if after_11 == '1':
        universities = universities.filter(accepts_after_grade_11=True)

    countries = (
        University.objects.filter(is_verified=True)
        .values_list('country', flat=True)
        .distinct()
        .order_by('country')
    )

    context = {
        'universities': universities,
        'countries': countries,
        'search_query': query,
        'selected_country': country,
        'after_11': after_11,
    }
    return render(request, 'marketplace/university_list.html', context)


def university_detail(request, pk):
    university = get_object_or_404(University, pk=pk)
    guides = university.guides.filter(
        verification_status=GuideProfile.STATUS_VERIFIED
    ).select_related('user')
    scholarships = university.scholarships.all()

    context = {
        'university': university,
        'guides': guides,
        'scholarships': scholarships,
    }
    return render(request, 'marketplace/university_detail.html', context)


def guide_list(request):
    query = request.GET.get('q', '').strip()
    country = request.GET.get('country', '').strip()
    university_id = request.GET.get('university', '').strip()
    scholarship_only = request.GET.get('scholarship', '').strip()

    guides = GuideProfile.objects.filter(
        verification_status=GuideProfile.STATUS_VERIFIED
    ).select_related('user', 'university')

    if query:
        guides = guides.filter(
            Q(user__full_name__icontains=query)
            | Q(major__icontains=query)
            | Q(university__name__icontains=query)
            | Q(university__country__icontains=query)
            | Q(experience_description__icontains=query)
        )
    if country:
        guides = guides.filter(university__country__iexact=country)
    if university_id.isdigit():
        guides = guides.filter(university_id=int(university_id))
    if scholarship_only == '1':
        guides = guides.filter(has_scholarship=True)

    countries = (
        University.objects.filter(is_verified=True)
        .values_list('country', flat=True)
        .distinct()
        .order_by('country')
    )
    universities = University.objects.filter(is_verified=True).order_by('name')

    context = {
        'guides': guides,
        'countries': countries,
        'universities': universities,
        'search_query': query,
        'selected_country': country,
        'selected_university': university_id,
        'scholarship_only': scholarship_only,
    }
    return render(request, 'marketplace/guide_list.html', context)


def guide_detail(request, pk):
    guide_profile = get_object_or_404(
        GuideProfile.objects.select_related('user', 'university'),
        pk=pk,
    )
    form = MessageForm()

    if request.method == 'POST':
        if not request.user.is_authenticated:
            messages.info(request, 'Пожалуйста, войдите или создайте аккаунт абитуриента, чтобы написать гиду.')
            return redirect('login')

        form = MessageForm(request.POST)
        if form.is_valid():
            msg = form.save(commit=False)
            msg.applicant = request.user
            msg.guide = guide_profile.user
            msg.sender = request.user
            msg.save()
            messages.success(
                request,
                f'Ваше сообщение успешно отправлено наставнику {guide_profile.user.full_name}!',
            )
            return redirect('conversation', partner_id=guide_profile.user.id)

    other_guides = (
        GuideProfile.objects.filter(
            university__country=guide_profile.university.country,
            verification_status=GuideProfile.STATUS_VERIFIED,
        )
        .exclude(pk=guide_profile.pk)
        .select_related('user', 'university')[:3]
    )

    context = {
        'guide_profile': guide_profile,
        'form': form,
        'other_guides': other_guides,
    }
    return render(request, 'marketplace/guide_detail.html', context)


def scholarship_list(request):
    country = request.GET.get('country', '').strip()
    coverage = request.GET.get('coverage', '').strip()
    query = request.GET.get('q', '').strip()

    scholarships = Scholarship.objects.select_related('university')
    if country:
        scholarships = scholarships.filter(country__iexact=country)
    if coverage:
        scholarships = scholarships.filter(coverage_type=coverage)
    if query:
        scholarships = scholarships.filter(
            Q(title__icontains=query)
            | Q(conditions__icontains=query)
            | Q(university__name__icontains=query)
            | Q(country__icontains=query)
        )

    countries = (
        Scholarship.objects.values_list('country', flat=True)
        .distinct()
        .order_by('country')
    )

    context = {
        'scholarships': scholarships,
        'countries': countries,
        'selected_country': country,
        'selected_coverage': coverage,
        'search_query': query,
    }
    return render(request, 'marketplace/scholarship_list.html', context)


def register_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            if user.is_guide:
                messages.success(
                    request,
                    'Аккаунт гида создан! Теперь заполните ваш профиль студента/выпускника для проверки администратором.',
                )
                return redirect('guide_profile_edit')
            messages.success(
                request,
                f'Добро пожаловать, {user.full_name or user.username}! Теперь вы можете искать вузы и писать гидам.',
            )
            return redirect('home')
    else:
        initial_role = request.GET.get('role', User.ROLE_APPLICANT)
        form = UserRegistrationForm(initial={'role': initial_role})

    return render(request, 'marketplace/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'С возвращением, {user.full_name or user.username}!')
            return redirect('home')
    else:
        form = CustomLoginForm()

    return render(request, 'marketplace/login.html', {'form': form})


def demo_login_view(request, role):
    """
    Быстрый вход в 1 клик для демонстрации трёх ролей:
    - applicant (Абитуриент Далер из Душанбе)
    - guide (Гид Фарзона — студентка в Малайзии)
    - admin (Администратор платформы)
    """
    role_map = {
        'applicant': 'daler_applicant',
        'guide': 'farzona_malaysia',
        'admin': 'admin',
    }
    username = role_map.get(role)
    user = User.objects.filter(username=username).first()
    if user:
        login(request, user)
        messages.success(
            request,
            f'Вы вошли в демо-режиме как {user.full_name} ({user.get_role_display()}).',
        )
        if role == 'admin':
            return redirect('moderation_dashboard')
        return redirect('home')

    messages.error(request, 'Демо-пользователь не найден. Запустите seed_data.')
    return redirect('login')


def logout_view(request):
    logout(request)
    messages.info(request, 'Вы вышли из аккаунта.')
    return redirect('home')


@login_required
def guide_profile_edit(request):
    profile = getattr(request.user, 'guide_profile', None)
    if request.method == 'POST':
        form = GuideProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            guide_profile = form.save(commit=False)
            guide_profile.user = request.user
            if request.user.role != User.ROLE_ADMIN:
                request.user.role = User.ROLE_GUIDE
                request.user.save(update_fields=['role'])
            guide_profile.save()
            messages.success(
                request,
                'Профиль наставника сохранён! После подтверждения администратором он получит значок Verified.',
            )
            return redirect('guide_detail', pk=guide_profile.pk)
    else:
        form = GuideProfileForm(instance=profile)

    return render(request, 'marketplace/guide_profile_form.html', {
        'form': form,
        'profile': profile,
    })


@login_required
def inbox_view(request):
    user_messages = Message.objects.filter(
        Q(applicant=request.user) | Q(guide=request.user)
    ).select_related('applicant', 'guide', 'sender').order_by('-created_at')

    partners_map = {}
    for msg in user_messages:
        partner = msg.guide if msg.applicant == request.user else msg.applicant
        if partner.id not in partners_map:
            unread = Message.objects.filter(
                Q(applicant=request.user, guide=partner) | Q(applicant=partner, guide=request.user),
                sender=partner,
                is_read=False,
            ).count()
            partners_map[partner.id] = {
                'partner': partner,
                'last_message': msg,
                'unread_count': unread,
            }

    return render(request, 'marketplace/inbox.html', {
        'conversations': list(partners_map.values()),
    })


@login_required
def conversation_view(request, partner_id):
    partner = get_object_or_404(User, pk=partner_id)

    thread = Message.objects.filter(
        Q(applicant=request.user, guide=partner) | Q(applicant=partner, guide=request.user)
    ).select_related('sender').order_by('created_at')

    thread.filter(sender=partner, is_read=False).update(is_read=True)

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            msg = form.save(commit=False)
            if request.user.is_guide and not partner.is_guide:
                msg.guide = request.user
                msg.applicant = partner
            elif partner.is_guide:
                msg.guide = partner
                msg.applicant = request.user
            else:
                msg.applicant = request.user
                msg.guide = partner
            msg.sender = request.user
            msg.save()
            return redirect('conversation', partner_id=partner.id)
    else:
        last_topic = thread.last().topic if thread.exists() else 'admission_11'
        form = MessageForm(initial={'topic': last_topic})

    partner_guide_profile = getattr(partner, 'guide_profile', None)

    return render(request, 'marketplace/conversation.html', {
        'partner': partner,
        'partner_guide_profile': partner_guide_profile,
        'thread': thread,
        'form': form,
    })


@login_required
def moderation_dashboard(request):
    if not request.user.is_platform_admin:
        messages.error(request, 'Доступ к панели модерации открыт только администраторам.')
        return redirect('home')

    if request.method == 'POST':
        action = request.POST.get('action')
        target_id = request.POST.get('target_id')

        if action == 'verify_guide':
            gp = get_object_or_404(GuideProfile, pk=target_id)
            gp.verification_status = GuideProfile.STATUS_VERIFIED
            gp.save(update_fields=['verification_status'])
            messages.success(request, f'Гид {gp.user.full_name} успешно подтверждён (Verified)!')
        elif action == 'reject_guide':
            gp = get_object_or_404(GuideProfile, pk=target_id)
            gp.verification_status = GuideProfile.STATUS_REJECTED
            gp.save(update_fields=['verification_status'])
            messages.warning(request, f'Статус гида {gp.user.full_name} изменён на «Отклонён».')
        elif action == 'delete_guide':
            gp = get_object_or_404(GuideProfile, pk=target_id)
            name = gp.user.full_name
            gp.delete()
            messages.info(request, f'Недостоверный профиль гида {name} удалён.')
        elif action == 'toggle_university':
            uni = get_object_or_404(University, pk=target_id)
            uni.is_verified = not uni.is_verified
            uni.save(update_fields=['is_verified'])
            status_label = 'подтверждён' if uni.is_verified else 'скрыт на проверку'
            messages.success(request, f'Университет «{uni.name}» {status_label}.')
        elif action == 'add_university':
            uni_form = UniversityForm(request.POST)
            if uni_form.is_valid():
                uni = uni_form.save(commit=False)
                uni.is_verified = True
                uni.save()
                messages.success(request, f'Университет «{uni.name}» добавлен и подтверждён!')
                return redirect('moderation_dashboard')

        return redirect('moderation_dashboard')

    pending_guides = GuideProfile.objects.filter(
        verification_status=GuideProfile.STATUS_PENDING
    ).select_related('user', 'university')
    all_guides = GuideProfile.objects.select_related('user', 'university').all()
    all_universities = University.objects.all()
    all_users = User.objects.order_by('-date_joined')[:20]
    uni_form = UniversityForm()

    return render(request, 'marketplace/moderation_dashboard.html', {
        'pending_guides': pending_guides,
        'all_guides': all_guides,
        'all_universities': all_universities,
        'all_users': all_users,
        'uni_form': uni_form,
    })


def robots_txt(request):
    sitemap_url = request.build_absolute_uri(reverse('sitemap_xml'))
    lines = [
        'User-agent: *',
        'Allow: /',
        'Disallow: /admin/',
        'Disallow: /moderation/',
        'Disallow: /inbox/',
        'Disallow: /conversation/',
        f'Sitemap: {sitemap_url}',
    ]
    return HttpResponse('\n'.join(lines), content_type='text/plain; charset=utf-8')


def sitemap_xml(request):
    urls = [
        request.build_absolute_uri(reverse('home')),
        request.build_absolute_uri(reverse('university_list')),
        request.build_absolute_uri(reverse('guide_list')),
        request.build_absolute_uri(reverse('scholarship_list')),
        request.build_absolute_uri(reverse('register')),
    ]
    for uni in University.objects.filter(is_verified=True):
        urls.append(request.build_absolute_uri(reverse('university_detail', args=[uni.pk])))
    for guide in GuideProfile.objects.filter(verification_status=GuideProfile.STATUS_VERIFIED):
        urls.append(request.build_absolute_uri(reverse('guide_detail', args=[guide.pk])))

    xml_items = ''.join(f'<url><loc>{u}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>' for u in urls)
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        f'{xml_items}'
        '</urlset>'
    )
    return HttpResponse(xml, content_type='application/xml; charset=utf-8')

