from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .models import User, University, GuideProfile, Message


class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={
            'class': 'form-input',
            'placeholder': 'Придумайте надёжный пароль',
        }),
    )
    role = forms.ChoiceField(
        label='Кем вы являетесь?',
        choices=[
            (User.ROLE_APPLICANT, 'Абитуриент (Applicant) — ищу университет и наставника'),
            (User.ROLE_GUIDE, 'Гид / Наставник (Guide) — уже учусь или окончил зарубежный вуз'),
        ],
        widget=forms.RadioSelect(attrs={'class': 'role-radio'}),
        initial=User.ROLE_APPLICANT,
    )

    class Meta:
        model = User
        fields = ['username', 'full_name', 'email', 'country_of_origin', 'role', 'password']
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: daler_tj',
            }),
            'full_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: Далер Рахимов',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-input',
                'placeholder': 'example@mail.com',
            }),
            'country_of_origin': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: Таджикистан, Душанбе',
            }),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        if commit:
            user.save()
        return user


class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(
        label='Логин пользователя',
        widget=forms.TextInput(attrs={
            'class': 'form-input',
            'placeholder': 'Введите логин',
        }),
    )
    password = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={
            'class': 'form-input',
            'placeholder': 'Введите пароль',
        }),
    )


class GuideProfileForm(forms.ModelForm):
    class Meta:
        model = GuideProfile
        fields = [
            'university',
            'major',
            'academic_status',
            'study_year',
            'avatar_photo',
            'verification_document_info',
            'student_id_file',
            'telegram_username',
            'whatsapp_phone',
            'instagram_handle',
            'linkedin_url',
            'has_scholarship',
            'scholarship_details',
            'languages',
            'experience_description',
            'can_help_with',
        ]
        widgets = {
            'university': forms.Select(attrs={'class': 'form-input'}),
            'major': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: Computer Science / Международные отношения',
            }),
            'academic_status': forms.Select(attrs={'class': 'form-input'}),
            'study_year': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: 3 курс бакалавриата / Выпуск 2025',
            }),
            'avatar_photo': forms.ClearableFileInput(attrs={'class': 'form-input'}),
            'verification_document_info': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Номер студенческого билета или университетский email для проверки админом',
            }),
            'student_id_file': forms.ClearableFileInput(attrs={'class': 'form-input'}),
            'telegram_username': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: @username или https://t.me/username',
            }),
            'whatsapp_phone': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: +992900123456',
            }),
            'instagram_handle': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: @my_instagram',
            }),
            'linkedin_url': forms.URLInput(attrs={
                'class': 'form-input',
                'placeholder': 'https://linkedin.com/in/...',
            }),
            'has_scholarship': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
            'scholarship_details': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Например: Полный грант CSC / Стипендия DSU (€6,500/год)',
            }),
            'languages': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Таджикский, Русский, Английский, Китайский',
            }),
            'experience_description': forms.Textarea(attrs={
                'class': 'form-input',
                'rows': 5,
                'placeholder': 'Расскажите, как вы поступили после школы, какие экзамены сдавали, сколько реально уходит денег на жизнь и учёбу...',
            }),
            'can_help_with': forms.Textarea(attrs={
                'class': 'form-input',
                'rows': 3,
                'placeholder': 'Проверка мотивационного письма, подача на визу, выбор общежития...',
            }),
        }


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['topic', 'content']
        widgets = {
            'topic': forms.Select(attrs={'class': 'form-input'}),
            'content': forms.Textarea(attrs={
                'class': 'form-input',
                'rows': 4,
                'placeholder': 'Напишите ваш вопрос гиду: например, как поступить после 11 класса, какие документы переводить, реально ли получить полную стипендию...',
            }),
        }


class UniversityForm(forms.ModelForm):
    class Meta:
        model = University
        fields = [
            'name',
            'country',
            'city',
            'flag_emoji',
            'website',
            'programs',
            'language_of_instruction',
            'tuition_fee',
            'living_cost',
            'accepts_after_grade_11',
            'after_grade_11_info',
            'required_documents',
            'visa_info',
            'student_life',
            'ranking_badge',
        ]
        widgets = {
            field: forms.TextInput(attrs={'class': 'form-input'})
            for field in ['name', 'country', 'city', 'flag_emoji', 'website', 'language_of_instruction', 'tuition_fee', 'living_cost', 'ranking_badge']
        } | {
            field: forms.Textarea(attrs={'class': 'form-input', 'rows': 3})
            for field in ['programs', 'after_grade_11_info', 'required_documents', 'visa_info', 'student_life']
        }
