from django.test import TestCase
from django.urls import reverse
from django.core.management import call_command
from .models import User, University, GuideProfile, Scholarship, Message


class MarketplaceMVPTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command('seed_data')

    def test_seed_data_clean_and_real(self):
        self.assertGreaterEqual(University.objects.count(), 6)
        self.assertGreaterEqual(Scholarship.objects.count(), 5)
        self.assertEqual(GuideProfile.objects.count(), 0)

    def test_public_pages_and_seo_endpoints(self):
        for url_name in [
            'home',
            'university_list',
            'guide_list',
            'scholarship_list',
            'login',
            'register',
            'robots_txt',
            'sitemap_xml',
        ]:
            response = self.client.get(reverse(url_name))
            self.assertEqual(response.status_code, 200, f"Failed on {url_name}")

        sitemap_resp = self.client.get(reverse('sitemap_xml'))
        self.assertContains(sitemap_resp, '<urlset')
        self.assertContains(sitemap_resp, '/universities/1/')

    def test_real_guide_registration_verification_and_messaging(self):
        uni = University.objects.first()
        guide_user = User.objects.create_user(
            username='real_student_guide',
            full_name='Алишер Каримов',
            email='alisher@apu.edu.my',
            password='password123',
            role=User.ROLE_GUIDE,
        )
        gp = GuideProfile.objects.create(
            user=guide_user,
            university=uni,
            major='Computer Science',
            study_year='2 курс',
            telegram_username='@alisher_apu',
            whatsapp_phone='+60123456789',
            experience_description='Поступил сам после 11 класса.',
        )
        self.assertEqual(gp.telegram_url, 'https://t.me/alisher_apu')
        self.assertEqual(gp.whatsapp_url, 'https://wa.me/60123456789')
        self.assertEqual(gp.verification_status, GuideProfile.STATUS_PENDING)

        # Admin verifies the guide
        self.client.login(username='admin', password='admin123')
        response = self.client.post(
            reverse('moderation_dashboard'),
            {'action': 'verify_guide', 'target_id': gp.id},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        gp.refresh_from_db()
        self.assertTrue(gp.is_verified)

        # Applicant sends a message to the verified guide
        applicant = User.objects.create_user(
            username='real_applicant',
            full_name='Самир Назаров',
            email='samir@mail.tj',
            password='password123',
            role=User.ROLE_APPLICANT,
        )
        self.client.login(username='real_applicant', password='password123')
        msg_resp = self.client.post(
            reverse('guide_detail', args=[gp.pk]),
            {'topic': 'admission_11', 'content': 'Привет! Подскажи по документам в APU.'},
            follow=True,
        )
        self.assertEqual(msg_resp.status_code, 200)
        self.assertTrue(Message.objects.filter(applicant=applicant, guide=guide_user).exists())
