@echo off
cd /d "%~dp0"
echo Starting University Guide Marketplace on http://127.0.0.1:8000/ ...
python manage.py runserver
pause
