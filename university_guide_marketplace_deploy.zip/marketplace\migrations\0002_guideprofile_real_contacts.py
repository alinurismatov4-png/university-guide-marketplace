from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('marketplace', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='guideprofile',
            name='avatar_photo',
            field=models.FileField(blank=True, null=True, upload_to='guides/photos/', verbose_name='Фотография профиля (JPG/PNG)'),
        ),
        migrations.AddField(
            model_name='guideprofile',
            name='student_id_file',
            field=models.FileField(blank=True, null=True, upload_to='guides/documents/', verbose_name='Фото/скан студенческого билета или диплома (видит только администратор)'),
        ),
        migrations.AddField(
            model_name='guideprofile',
            name='telegram_username',
            field=models.CharField(blank=True, help_text='Например: @my_telegram или https://t.me/my_telegram', max_length=120, verbose_name='Telegram (никнейм или ссылка)'),
        ),
        migrations.AddField(
            model_name='guideprofile',
            name='whatsapp_phone',
            field=models.CharField(blank=True, help_text='Например: +992900123456 или +60123456789', max_length=50, verbose_name='WhatsApp (номер телефона с кодом страны)'),
        ),
        migrations.AddField(
            model_name='guideprofile',
            name='instagram_handle',
            field=models.CharField(blank=True, help_text='Например: @my_insta', max_length=120, verbose_name='Instagram (никнейм или ссылка)'),
        ),
        migrations.AddField(
            model_name='guideprofile',
            name='linkedin_url',
            field=models.URLField(blank=True, max_length=250, verbose_name='Профиль LinkedIn'),
        ),
    ]
