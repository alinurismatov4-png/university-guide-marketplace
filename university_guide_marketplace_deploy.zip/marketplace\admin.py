from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, University, GuideProfile, Scholarship, Message


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'full_name', 'email', 'role', 'country_of_origin', 'is_staff')
    list_filter = ('role', 'is_staff', 'is_active')
    fieldsets = UserAdmin.fieldsets + (
        ('Дополнительная информация платформы', {
            'fields': ('full_name', 'role', 'country_of_origin'),
        }),
    )


@admin.register(University)
class UniversityAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'city', 'tuition_fee', 'accepts_after_grade_11', 'is_verified')
    list_filter = ('country', 'accepts_after_grade_11', 'is_verified')
    search_fields = ('name', 'country', 'city', 'programs')


@admin.register(GuideProfile)
class GuideProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'university', 'major', 'academic_status', 'verification_status', 'has_scholarship')
    list_filter = ('verification_status', 'academic_status', 'has_scholarship', 'university__country')
    search_fields = ('user__full_name', 'user__username', 'university__name', 'major')
    actions = ['approve_guides', 'reject_guides']

    @admin.action(description='Подтвердить выбранных гидов (Verified)')
    def approve_guides(self, request, queryset):
        queryset.update(verification_status=GuideProfile.STATUS_VERIFIED)

    @admin.action(description='Отклонить выбранных гидов')
    def reject_guides(self, request, queryset):
        queryset.update(verification_status=GuideProfile.STATUS_REJECTED)


@admin.register(Scholarship)
class ScholarshipAdmin(admin.ModelAdmin):
    list_display = ('title', 'country', 'university', 'coverage_type', 'deadline')
    list_filter = ('country', 'coverage_type')
    search_fields = ('title', 'country', 'university__name')


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'applicant', 'guide', 'topic', 'created_at', 'is_read')
    list_filter = ('topic', 'is_read', 'created_at')
    search_fields = ('content', 'applicant__username', 'guide__username')
