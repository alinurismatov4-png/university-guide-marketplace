from django.db.models import Q
from .models import Message, GuideProfile


def unread_messages_count(request):
    if not request.user.is_authenticated:
        return {'unread_count': 0, 'pending_guides_count': 0}

    unread = Message.objects.filter(
        Q(applicant=request.user) | Q(guide=request.user),
        is_read=False,
    ).exclude(sender=request.user).count()

    pending_guides = 0
    if request.user.is_platform_admin:
        pending_guides = GuideProfile.objects.filter(
            verification_status=GuideProfile.STATUS_PENDING
        ).count()

    return {
        'unread_count': unread,
        'pending_guides_count': pending_guides,
    }
